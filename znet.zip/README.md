
# Znet - ConnectNow Deployment Guide

This app is ready to be published! Follow these steps to get it online.

## Option A: Vercel (Easiest)
1. Go to [vercel.com](https://vercel.com).
2. Create a free account.
3. Install the Vercel CLI: `npm install -g vercel`.
4. Run `vercel` in this folder.
5. Follow the prompts. Your app will be live at a `*.vercel.app` URL.

## Option B: GitHub + Netlify
1. Create a new repository on [GitHub](https://github.com).
2. Upload these files to the repository.
3. Go to [Netlify](https://netlify.com) and click "Import from GitHub".
4. Select your repo. It will automatically publish every time you update your code.

## Mobile Installation
Once hosted, open the URL on your iPhone (Safari) or Android (Chrome):
- **iPhone**: Tap 'Share' -> 'Add to Home Screen'.
- **Android**: Tap the 'Install' prompt or 'Add to Home Screen'.
